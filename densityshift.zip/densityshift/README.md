# DensityShift

DensityShift is a Discord.js v14 bot that helps community admins announce a
server migration to their members via **direct message**, in a way that
fully respects Discord's Terms of Service, API rate limits, and user
privacy settings.

## What it does NOT do

- It does **not** force anyone to join another server.
- It does **not** bypass Discord's rate limits, permission model, or privacy
  settings (users who disable DMs from server members, or who block the bot,
  are automatically skipped).
- It does **not** message anyone who isn't a verifiable member of a guild
  the bot is installed in.
- It does **not** spam — sends are deliberately spaced out and Discord's
  own rate limiting is respected at every step.

## Features

- `/shift` — start (or resume) a migration campaign
  - `title` — announcement title
  - `message` — announcement body
  - `invite` — invite link to the new server (previewed automatically)
  - `icon` — optional image attachment shown in the DM
  - `test` — send yourself a preview DM before going live
- `/status` — live progress of the current/last campaign
- `/stop` — gracefully halt a running campaign (resumable later)
- `/stats` — all-time migration statistics for the server

## Requirements

- Node.js **22+**
- A Discord application/bot with:
  - `bot` and `applications.commands` scopes
  - **Server Members Intent** enabled in the Developer Portal
  - Permission to view the channel it posts progress updates in

## Setup

1. **Install dependencies**

   ```bash
   npm install
   ```

2. **Configure environment variables**

   Copy `.env.example` to `.env` and fill in your values:

   ```bash
   cp .env.example .env
   ```

   | Variable | Description |
   |---|---|
   | `DISCORD_TOKEN` | Your bot's token |
   | `CLIENT_ID` | Your application's client ID |
   | `GUILD_ID` | (Optional, dev only) Register commands instantly to one test server |

3. **Register slash commands**

   ```bash
   npm run deploy
   ```

4. **Start the bot**

   ```bash
   npm start
   ```

   For local development with auto-restart on file changes:

   ```bash
   npm run dev
   ```

## Invite the bot

Generate an OAuth2 URL in the Developer Portal with the `bot` and
`applications.commands` scopes, and at minimum the **View Channels** and
**Send Messages** bot permissions (needed to post progress updates).

## How a campaign runs

1. An admin runs `/shift` with a title, message, and invite link.
2. The bot fetches an official Discord invite preview (server name, icon,
   member count) to include in the DM.
3. All current guild members are recorded in SQLite. Bots are marked as
   skipped immediately and never DM'd.
4. The bot works through members one at a time, waiting a configurable
   delay between each send (`config/config.json` → `rateLimit.delayBetweenDmsMs`)
   to stay well within safe usage patterns.
5. Users with closed DMs or who have blocked the bot are recorded as
   skipped, not retried indefinitely.
6. Progress updates post periodically to the channel `/shift` was run in.
7. `/stop` marks the campaign as stopped; running `/shift` again resumes
   exactly where it left off, skipping everyone already processed.
8. If the bot process crashes or restarts mid-campaign, it automatically
   detects the interrupted campaign on boot and resumes it — no manual
   action needed.

## Configuration

Edit `config/config.json`:

```json
{
  "embedColor": "#5865F2",
  "rateLimit": {
    "delayBetweenDmsMs": 3000
  },
  "progressUpdateEvery": 15,
  "logging": {
    "level": "info",
    "toFile": true,
    "logDir": "./logs"
  },
  "database": {
    "path": "./data/densityshift.sqlite"
  }
}
```

## Data & Logs

- Progress is tracked in a local SQLite database at `data/densityshift.sqlite`.
- Detailed logs are written to `logs/densityshift.log` and to the console.

## Folder Structure

```
densityshift/
├── package.json
├── .env.example
├── config/config.json
├── data/                 # SQLite database (generated at runtime)
├── logs/                 # Log files (generated at runtime)
└── src/
    ├── index.js
    ├── deploy-commands.js
    ├── commands/
    ├── database/
    ├── services/
    └── utils/
```

## License

MIT
