require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('node:fs');
const path = require('node:path');
const logger = require('./utils/logger');

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command.data && typeof command.execute === 'function') {
    commands.push(command.data.toJSON());
  } else {
    logger.warn(`Command file ${file} is missing "data" or "execute" — skipped.`);
  }
}

const { DISCORD_TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!DISCORD_TOKEN || !CLIENT_ID) {
  logger.error('DISCORD_TOKEN and CLIENT_ID must be set in your .env file.');
  process.exit(1);
}

const rest = new REST().setToken(DISCORD_TOKEN);

(async () => {
  try {
    logger.info(`Registering ${commands.length} slash command(s)...`);

    if (GUILD_ID) {
      await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
      logger.info(`Successfully registered commands to guild ${GUILD_ID} (instant, for development).`);
    } else {
      await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commands });
      logger.info('Successfully registered global commands (may take up to 1 hour to propagate).');
    }
  } catch (err) {
    logger.error(`Failed to register commands: ${err.stack || err.message}`);
    process.exit(1);
  }
})();
