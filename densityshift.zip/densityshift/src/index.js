require('dotenv').config();
const fs = require('node:fs');
const path = require('node:path');
const { Client, Collection, GatewayIntentBits, Events } = require('discord.js');
const logger = require('./utils/logger');
const db = require('./database/db');
const ShiftManager = require('./services/shiftManager');

const { DISCORD_TOKEN } = process.env;

if (!DISCORD_TOKEN) {
  logger.error('DISCORD_TOKEN is not set. Please configure your .env file.');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers, // Requires "Server Members Intent" enabled in the Dev Portal
  ],
});

client.commands = new Collection();

const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  if (command.data && typeof command.execute === 'function') {
    client.commands.set(command.data.name, command);
  } else {
    logger.warn(`Command file ${file} is missing required "data" or "execute" export.`);
  }
}

const shiftManager = new ShiftManager(client);

client.once(Events.ClientReady, async (readyClient) => {
  logger.info(`DensityShift is online as ${readyClient.user.tag}.`);
  await shiftManager.resumeInterruptedCampaigns();
});

client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) {
    logger.warn(`Received unknown command: ${interaction.commandName}`);
    return;
  }

  try {
    await command.execute(interaction, { client, db, logger, shiftManager });
  } catch (err) {
    logger.error(`Error executing /${interaction.commandName}: ${err.stack || err.message}`);
    const errorReply = { content: '❌ Something went wrong while running that command.', ephemeral: true };
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(errorReply).catch(() => {});
    } else {
      await interaction.reply(errorReply).catch(() => {});
    }
  }
});

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

function shutdown(signal) {
  logger.info(`Received ${signal}. Shutting down gracefully...`);
  db.close();
  client.destroy();
  process.exit(0);
}

client.login(DISCORD_TOKEN);
