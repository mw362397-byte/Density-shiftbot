const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { getInvitePreview } = require('../utils/invitePreview');
const { buildAnnouncementEmbed } = require('../utils/embeds');
const db = require('../database/db');
const logger = require('../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('shift')
    .setDescription('Start (or resume) a migration announcement campaign for this server')
    .addStringOption((opt) =>
      opt.setName('title').setDescription('Announcement title').setRequired(true).setMaxLength(256)
    )
    .addStringOption((opt) =>
      opt.setName('message').setDescription('Announcement message').setRequired(true).setMaxLength(2000)
    )
    .addStringOption((opt) =>
      opt.setName('invite').setDescription('Discord invite link to the new server').setRequired(true)
    )
    .addAttachmentOption((opt) =>
      opt.setName('icon').setDescription('Optional icon/image to show in the DM').setRequired(false)
    )
    .addBooleanOption((opt) =>
      opt
        .setName('test')
        .setDescription('Send yourself a test DM preview instead of starting the campaign')
        .setRequired(false)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction, { shiftManager }) {
    await interaction.deferReply({ ephemeral: true });

    const title = interaction.options.getString('title');
    const message = interaction.options.getString('message');
    const inviteLink = interaction.options.getString('invite');
    const icon = interaction.options.getAttachment('icon');
    const isTest = interaction.options.getBoolean('test') ?? false;
    const iconUrl = icon?.url ?? null;

    const invitePreview = await getInvitePreview(interaction.client, inviteLink);
    if (!invitePreview) {
      return interaction.editReply({
        content: '❌ That invite link looks invalid or expired. Please check it and try again.',
      });
    }

    if (isTest) {
      try {
        const embed = buildAnnouncementEmbed({ title, message, invitePreview, iconUrl });
        await interaction.user.send({
          content: '👋 This is a **test preview** of your migration DM. Nothing has been sent to members yet.',
          embeds: [embed],
        });
        return interaction.editReply({
          content: '✅ Test DM sent to you! Review it, then run `/shift` again with `test: False` to start the real campaign.',
        });
      } catch (err) {
        logger.warn(`Test DM failed for ${interaction.user.tag}: ${err.message}`);
        return interaction.editReply({
          content: '❌ Could not send you a test DM. Please enable DMs from server members and try again.',
        });
      }
    }

    const existing = db.getActiveCampaign(interaction.guild.id);

    if (existing && existing.status === 'running') {
      return interaction.editReply({
        content: '⚠️ A campaign is already running in this server. Use `/status` to check progress or `/stop` to halt it.',
      });
    }

    if (existing && existing.status === 'stopped') {
      shiftManager.resumeCampaign(existing);
      const stats = db.getCampaignStats(existing.id);
      return interaction.editReply({
        content:
          `▶️ Resuming your previous campaign ("${existing.title}") — ` +
          `${stats.pending} member(s) remaining. New progress updates will be posted in this channel.`,
      });
    }

    const campaign = await shiftManager.startCampaign({
      guild: interaction.guild,
      channel: interaction.channel,
      title,
      message,
      inviteLink,
      invitePreview,
      iconUrl,
      startedBy: interaction.user.id,
    });

    const embed = new EmbedBuilder()
      .setColor('#5865F2')
      .setTitle('🚀 Migration Campaign Started')
      .setDescription(
        `Announcing migration to **${invitePreview.guildName}**.\n` +
        `Members will be DM'd gradually and respectfully. Progress updates will post in this channel.`
      )
      .addFields(
        { name: 'Campaign ID', value: String(campaign.id), inline: true },
        { name: 'Target Server', value: invitePreview.guildName, inline: true }
      );

    return interaction.editReply({ embeds: [embed] });
  },
};
