const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { buildStatsEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stats')
    .setDescription('View all-time migration statistics for this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const stats = db.getGuildStats(interaction.guild.id);
    const embed = buildStatsEmbed(interaction.guild.name, stats);
    return interaction.editReply({ embeds: [embed] });
  },
};
