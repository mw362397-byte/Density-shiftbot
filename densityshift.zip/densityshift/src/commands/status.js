const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');
const { buildProgressEmbed } = require('../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('status')
    .setDescription('Check the progress of the current or most recent migration campaign')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction) {
    await interaction.deferReply({ ephemeral: true });

    const campaign = db.getLatestCampaign(interaction.guild.id);
    if (!campaign) {
      return interaction.editReply({ content: 'ℹ️ No migration campaign has been started in this server yet.' });
    }

    const stats = db.getCampaignStats(campaign.id);
    const embed = buildProgressEmbed(campaign, stats, campaign.status === 'completed');
    return interaction.editReply({ embeds: [embed] });
  },
};
