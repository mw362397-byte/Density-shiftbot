const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../database/db');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('stop')
    .setDescription('Stop the currently running migration campaign in this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false),

  async execute(interaction, { shiftManager }) {
    await interaction.deferReply({ ephemeral: true });

    const campaign = db.getActiveCampaign(interaction.guild.id);
    if (!campaign || campaign.status !== 'running') {
      return interaction.editReply({ content: 'ℹ️ There is no active campaign running in this server.' });
    }

    shiftManager.stopCampaign(interaction.guild.id);

    return interaction.editReply({
      content:
        '🛑 Stop requested. The campaign will halt shortly (after the current DM finishes sending). ' +
        'Run `/shift` again with the same details to resume later.',
    });
  },
};
