const config = require('../../config/config.json');
const logger = require('../utils/logger');
const db = require('../database/db');
const { RateLimiter } = require('../utils/rateLimiter');
const { buildAnnouncementEmbed, buildProgressEmbed } = require('../utils/embeds');

/**
 * Orchestrates migration campaigns: fetching members, sending DMs
 * within Discord's rate limits, tracking progress in SQLite, and
 * supporting graceful stop/resume.
 *
 * This manager NEVER attempts to circumvent Discord permissions or
 * rate limits. It only messages users who are verifiable members of
 * a guild the bot is installed in, and only if that user allows DMs
 * from server members.
 */
class ShiftManager {
  constructor(client) {
    this.client = client;
    this.stopFlags = new Map(); // guildId -> boolean
    this.activeGuilds = new Set(); // guildId currently processing
  }

  isRunning(guildId) {
    return this.activeGuilds.has(guildId);
  }

  async startCampaign({ guild, channel, title, message, inviteLink, invitePreview, iconUrl, startedBy }) {
    const campaign = db.createCampaign({
      guildId: guild.id,
      guildName: guild.name,
      channelId: channel.id,
      title,
      message,
      inviteLink,
      iconUrl,
      startedBy,
    });

    this.stopFlags.set(guild.id, false);
    this._runCampaign(campaign, invitePreview).catch((err) => {
      logger.error(`Unhandled error running campaign ${campaign.id}: ${err.stack || err.message}`);
    });

    return campaign;
  }

  resumeCampaign(campaign) {
    this.stopFlags.set(campaign.guild_id, false);
    db.updateCampaignStatus(campaign.id, 'running');
    this._runCampaign(campaign, null).catch((err) => {
      logger.error(`Unhandled error resuming campaign ${campaign.id}: ${err.stack || err.message}`);
    });
  }

  stopCampaign(guildId) {
    this.stopFlags.set(guildId, true);
  }

  async _runCampaign(campaign, invitePreview) {
    const guild = await this.client.guilds.fetch(campaign.guild_id).catch(() => null);
    if (!guild) {
      logger.error(`Cannot run campaign ${campaign.id}: bot is no longer in guild ${campaign.guild_id}.`);
      db.updateCampaignStatus(campaign.id, 'failed');
      return;
    }

    this.activeGuilds.add(campaign.guild_id);

    try {
      const existingTargetCount = db.countTargets(campaign.id);

      if (existingTargetCount === 0) {
        logger.info(`[Campaign ${campaign.id}] Fetching member list for guild "${guild.name}".`);
        const members = await guild.members.fetch();
        const rows = [...members.values()].map((member) => ({
          user_id: member.id,
          username: member.user.tag,
          status: member.user.bot ? 'skipped_bot' : 'pending',
        }));
        db.bulkInsertTargets(campaign.id, rows);
        logger.info(`[Campaign ${campaign.id}] Queued ${rows.length} members (bots pre-skipped).`);
      } else {
        logger.info(`[Campaign ${campaign.id}] Resuming existing campaign with ${existingTargetCount} tracked targets.`);
      }

      const rateLimiter = new RateLimiter(config.rateLimit.delayBetweenDmsMs);
      let sinceLastUpdate = 0;
      const channel = await this.client.channels.fetch(campaign.channel_id).catch(() => null);

      while (true) {
        if (this.stopFlags.get(campaign.guild_id)) {
          db.updateCampaignStatus(campaign.id, 'stopped');
          logger.info(`[Campaign ${campaign.id}] Stopped by request.`);
          break;
        }

        const target = db.getNextPendingTarget(campaign.id);
        if (!target) {
          db.updateCampaignStatus(campaign.id, 'completed');
          logger.info(`[Campaign ${campaign.id}] Completed — no pending targets remain.`);
          break;
        }

        await rateLimiter.wait();
        await this._processTarget(guild, campaign, target, invitePreview);

        sinceLastUpdate++;
        if (sinceLastUpdate >= config.progressUpdateEvery && channel) {
          sinceLastUpdate = 0;
          await this._postProgress(channel, campaign);
        }
      }

      if (channel) {
        const finalCampaign = db.getCampaignById(campaign.id);
        await this._postProgress(channel, finalCampaign, true);
      }
    } finally {
      this.activeGuilds.delete(campaign.guild_id);
    }
  }

  async _processTarget(guild, campaign, target, invitePreview) {
    try {
      const member = await guild.members.fetch(target.user_id);
      const embed = buildAnnouncementEmbed({
        title: campaign.title,
        message: campaign.message,
        invitePreview,
        iconUrl: campaign.icon_url,
      });

      await member.send({ embeds: [embed] });
      db.updateTargetStatus(target.id, 'sent');
      logger.info(`[Campaign ${campaign.id}] DM sent to ${target.username} (${target.user_id}).`);
    } catch (err) {
      if (err.code === 50007) {
        db.updateTargetStatus(target.id, 'skipped_dm_closed', 'DMs closed or bot blocked');
        logger.warn(`[Campaign ${campaign.id}] Skipped ${target.username}: DMs closed.`);
      } else if (err.code === 10007 || err.code === 10013) {
        db.updateTargetStatus(target.id, 'failed', 'Member no longer in guild');
        logger.warn(`[Campaign ${campaign.id}] Skipped ${target.username}: no longer a member.`);
      } else {
        db.updateTargetStatus(target.id, 'failed', err.message);
        logger.error(`[Campaign ${campaign.id}] Failed to DM ${target.username}: ${err.message}`);
      }
    }
  }

  async _postProgress(channel, campaign, finished = false) {
    try {
      const stats = db.getCampaignStats(campaign.id);
      const embed = buildProgressEmbed(campaign, stats, finished);
      await channel.send({ embeds: [embed] });
    } catch (err) {
      logger.warn(`Failed to post progress update: ${err.message}`);
    }
  }

  /**
   * Called once on bot startup. Any campaign still marked 'running'
   * means the process was interrupted (crash/restart) mid-campaign,
   * since a graceful /stop always sets status to 'stopped'.
   * These are automatically resumed from the last completed target.
   */
  async resumeInterruptedCampaigns() {
    const running = db.getAllRunningCampaigns();
    if (running.length === 0) return;

    logger.info(`Found ${running.length} interrupted campaign(s) to resume.`);
    for (const campaign of running) {
      logger.info(`Resuming interrupted campaign ${campaign.id} for guild ${campaign.guild_id}.`);
      this.resumeCampaign(campaign);
    }
  }
}

module.exports = ShiftManager;
