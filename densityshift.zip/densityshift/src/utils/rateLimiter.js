/**
 * Simple spacing-based rate limiter.
 * Ensures at least `delayMs` passes between consecutive DM sends,
 * on top of whatever internal rate limit handling discord.js already does.
 * This exists specifically to avoid tripping Discord's anti-spam heuristics
 * when sending many DMs in a short period — it does NOT attempt to bypass
 * or exceed any Discord-imposed limit.
 */
class RateLimiter {
  constructor(delayMs) {
    this.delayMs = delayMs;
    this.lastCall = 0;
  }

  async wait() {
    const now = Date.now();
    const elapsed = now - this.lastCall;
    if (elapsed < this.delayMs) {
      await sleep(this.delayMs - elapsed);
    }
    this.lastCall = Date.now();
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

module.exports = { RateLimiter, sleep };
