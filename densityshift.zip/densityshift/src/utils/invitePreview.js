const logger = require('./logger');

/**
 * Extracts an invite code from a full invite URL or raw code.
 */
function extractInviteCode(input) {
  if (!input) return null;
  const match = input.trim().match(
    /(?:discord\.gg\/|discord(?:app)?\.com\/invite\/)([\w-]+)/i
  );
  return match ? match[1] : input.trim();
}

/**
 * Fetches a public preview of an invite (guild name, icon, member counts)
 * without requiring the bot to be a member of the target server.
 * Returns null if the invite is invalid or expired.
 */
async function getInvitePreview(client, rawInvite) {
  const code = extractInviteCode(rawInvite);
  if (!code) return null;

  try {
    const invite = await client.fetchInvite(code);
    return {
      code,
      url: `https://discord.gg/${code}`,
      guildName: invite.guild?.name ?? 'Unknown Server',
      guildIcon: invite.guild?.iconURL?.() ?? null,
      memberCount: invite.memberCount ?? null,
      presenceCount: invite.presenceCount ?? null,
      expiresAt: invite.expiresTimestamp ?? null,
    };
  } catch (err) {
    logger.warn(`Failed to fetch invite preview for "${rawInvite}": ${err.message}`);
    return null;
  }
}

module.exports = { extractInviteCode, getInvitePreview };
