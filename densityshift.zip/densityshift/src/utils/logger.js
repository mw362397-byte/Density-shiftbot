const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config/config.json');

const LEVELS = { error: 0, warn: 1, info: 2, debug: 3 };
const configuredLevel = LEVELS[config.logging.level] ?? LEVELS.info;

let logFilePath = null;

if (config.logging.toFile) {
  const logDir = path.resolve(process.cwd(), config.logging.logDir);
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }
  logFilePath = path.join(logDir, config.logging.logFile);
}

function timestamp() {
  return new Date().toISOString();
}

function write(level, message) {
  if (LEVELS[level] > configuredLevel) return;

  const line = `[${timestamp()}] [${level.toUpperCase()}] ${message}`;

  const consoleMethod = level === 'error' ? 'error' : level === 'warn' ? 'warn' : 'log';
  // eslint-disable-next-line no-console
  console[consoleMethod](line);

  if (logFilePath) {
    fs.appendFile(logFilePath, line + '\n', (err) => {
      if (err) {
        // eslint-disable-next-line no-console
        console.error(`[${timestamp()}] [ERROR] Failed to write log file: ${err.message}`);
      }
    });
  }
}

module.exports = {
  error: (msg) => write('error', msg),
  warn: (msg) => write('warn', msg),
  info: (msg) => write('info', msg),
  debug: (msg) => write('debug', msg),
};
