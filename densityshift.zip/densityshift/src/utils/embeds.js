const { EmbedBuilder } = require('discord.js');
const config = require('../../config/config.json');

/**
 * Builds the DM embed sent to migrating members.
 */
function buildAnnouncementEmbed({ title, message, invitePreview, iconUrl }) {
  const embed = new EmbedBuilder()
    .setColor(config.embedColor)
    .setTitle(title)
    .setDescription(message)
    .setTimestamp();

  if (iconUrl) {
    embed.setThumbnail(iconUrl);
  } else if (invitePreview?.guildIcon) {
    embed.setThumbnail(invitePreview.guildIcon);
  }

  if (invitePreview) {
    embed.addFields(
      { name: 'New Server', value: invitePreview.guildName, inline: true },
      {
        name: 'Members',
        value: invitePreview.memberCount ? invitePreview.memberCount.toLocaleString() : 'Unknown',
        inline: true,
      },
      { name: 'Join Here', value: invitePreview.url }
    );
  } else {
    embed.addFields({ name: 'Join Here', value: message.includes('http') ? '' : '' });
  }

  embed.setFooter({
    text: "You're receiving this because you're a member of a server that is migrating to a new home.",
  });

  return embed;
}

function buildProgressEmbed(campaign, stats, finished = false) {
  const total = stats.total || 0;
  const processed = stats.sent + stats.failed + stats.skipped_dm_closed + stats.skipped_bot;
  const percent = total > 0 ? Math.round((processed / total) * 100) : 0;

  return new EmbedBuilder()
    .setColor(finished ? '#57F287' : config.embedColor)
    .setTitle(finished ? '✅ Migration Campaign Finished' : '📨 Migration Campaign In Progress')
    .addFields(
      { name: 'Status', value: campaign.status, inline: true },
      { name: 'Progress', value: `${percent}% (${processed}/${total})`, inline: true },
      { name: '✅ Sent', value: String(stats.sent), inline: true },
      { name: '❌ Failed', value: String(stats.failed), inline: true },
      { name: '🚫 Closed DMs', value: String(stats.skipped_dm_closed), inline: true },
      { name: '🤖 Bots Skipped', value: String(stats.skipped_bot), inline: true }
    )
    .setTimestamp();
}

function buildStatsEmbed(guildName, stats) {
  return new EmbedBuilder()
    .setColor(config.embedColor)
    .setTitle(`📊 DensityShift Stats — ${guildName}`)
    .addFields(
      { name: 'Total Campaigns', value: String(stats.totalCampaigns), inline: true },
      { name: 'Total DMs Sent', value: String(stats.totalSent), inline: true },
      { name: 'Total Failed', value: String(stats.totalFailed), inline: true },
      { name: 'Total Closed DMs', value: String(stats.totalClosedDm), inline: true },
      { name: 'Total Bots Skipped', value: String(stats.totalBotsSkipped), inline: true },
      {
        name: 'Success Rate',
        value: stats.totalAttempted > 0
          ? `${Math.round((stats.totalSent / stats.totalAttempted) * 100)}%`
          : 'N/A',
        inline: true,
      }
    )
    .setTimestamp();
}

module.exports = { buildAnnouncementEmbed, buildProgressEmbed, buildStatsEmbed };
