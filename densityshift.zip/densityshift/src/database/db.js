const path = require('node:path');
const fs = require('node:fs');
const Database = require('better-sqlite3');
const config = require('../../config/config.json');
const logger = require('../utils/logger');

const dbPath = path.resolve(process.cwd(), config.database.path);
const dbDir = path.dirname(dbPath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id TEXT NOT NULL,
    guild_name TEXT,
    channel_id TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    invite_link TEXT NOT NULL,
    icon_url TEXT,
    status TEXT NOT NULL DEFAULT 'running',
    started_by TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS targets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL,
    username TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    error TEXT,
    attempted_at INTEGER,
    UNIQUE(campaign_id, user_id)
  );

  CREATE INDEX IF NOT EXISTS idx_targets_campaign_status ON targets(campaign_id, status);
`);

// ---------- Campaigns ----------

function createCampaign({ guildId, guildName, channelId, title, message, inviteLink, iconUrl, startedBy }) {
  const now = Date.now();
  const stmt = db.prepare(`
    INSERT INTO campaigns (guild_id, guild_name, channel_id, title, message, invite_link, icon_url, status, started_by, created_at, updated_at)
    VALUES (@guildId, @guildName, @channelId, @title, @message, @inviteLink, @iconUrl, 'running', @startedBy, @now, @now)
  `);
  const info = stmt.run({ guildId, guildName, channelId, title, message, inviteLink, iconUrl: iconUrl ?? null, startedBy, now });
  return getCampaignById(info.lastInsertRowid);
}

function getCampaignById(id) {
  return db.prepare(`SELECT * FROM campaigns WHERE id = ?`).get(id);
}

function getActiveCampaign(guildId) {
  return db.prepare(`
    SELECT * FROM campaigns
    WHERE guild_id = ? AND status IN ('running', 'paused', 'stopped')
    ORDER BY created_at DESC
    LIMIT 1
  `).get(guildId);
}

function getLatestCampaign(guildId) {
  return db.prepare(`
    SELECT * FROM campaigns WHERE guild_id = ? ORDER BY created_at DESC LIMIT 1
  `).get(guildId);
}

function getAllRunningCampaigns() {
  return db.prepare(`SELECT * FROM campaigns WHERE status = 'running'`).all();
}

function updateCampaignStatus(id, status) {
  db.prepare(`UPDATE campaigns SET status = ?, updated_at = ? WHERE id = ?`).run(status, Date.now(), id);
}

// ---------- Targets ----------

function countTargets(campaignId) {
  const row = db.prepare(`SELECT COUNT(*) as count FROM targets WHERE campaign_id = ?`).get(campaignId);
  return row.count;
}

const insertTargetStmt = db.prepare(`
  INSERT OR IGNORE INTO targets (campaign_id, user_id, username, status)
  VALUES (@campaignId, @userId, @username, @status)
`);

function bulkInsertTargets(campaignId, rows) {
  const insertMany = db.transaction((items) => {
    for (const item of items) {
      insertTargetStmt.run({
        campaignId,
        userId: item.user_id,
        username: item.username,
        status: item.status,
      });
    }
  });
  insertMany(rows);
}

function getNextPendingTarget(campaignId) {
  return db.prepare(`
    SELECT * FROM targets WHERE campaign_id = ? AND status = 'pending' LIMIT 1
  `).get(campaignId);
}

function updateTargetStatus(id, status, error = null) {
  db.prepare(`
    UPDATE targets SET status = ?, error = ?, attempted_at = ? WHERE id = ?
  `).run(status, error, Date.now(), id);
}

function getCampaignStats(campaignId) {
  const rows = db.prepare(`
    SELECT status, COUNT(*) as count FROM targets WHERE campaign_id = ? GROUP BY status
  `).all(campaignId);

  const stats = { total: 0, pending: 0, sent: 0, failed: 0, skipped_bot: 0, skipped_dm_closed: 0 };
  for (const row of rows) {
    stats[row.status] = row.count;
    stats.total += row.count;
  }
  return stats;
}

function getGuildStats(guildId) {
  const campaigns = db.prepare(`SELECT id FROM campaigns WHERE guild_id = ?`).all(guildId);
  const totalCampaigns = campaigns.length;

  if (totalCampaigns === 0) {
    return {
      totalCampaigns: 0,
      totalSent: 0,
      totalFailed: 0,
      totalClosedDm: 0,
      totalBotsSkipped: 0,
      totalAttempted: 0,
    };
  }

  const ids = campaigns.map((c) => c.id);
  const placeholders = ids.map(() => '?').join(',');
  const rows = db.prepare(`
    SELECT status, COUNT(*) as count FROM targets WHERE campaign_id IN (${placeholders}) GROUP BY status
  `).all(...ids);

  const result = { totalCampaigns, totalSent: 0, totalFailed: 0, totalClosedDm: 0, totalBotsSkipped: 0, totalAttempted: 0 };
  for (const row of rows) {
    if (row.status === 'sent') result.totalSent = row.count;
    if (row.status === 'failed') result.totalFailed = row.count;
    if (row.status === 'skipped_dm_closed') result.totalClosedDm = row.count;
    if (row.status === 'skipped_bot') result.totalBotsSkipped = row.count;
  }
  result.totalAttempted = result.totalSent + result.totalFailed + result.totalClosedDm;
  return result;
}

function close() {
  logger.info('Closing database connection.');
  db.close();
}

module.exports = {
  createCampaign,
  getCampaignById,
  getActiveCampaign,
  getLatestCampaign,
  getAllRunningCampaigns,
  updateCampaignStatus,
  countTargets,
  bulkInsertTargets,
  getNextPendingTarget,
  updateTargetStatus,
  getCampaignStats,
  getGuildStats,
  close,
};
